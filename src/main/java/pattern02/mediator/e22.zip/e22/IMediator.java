package pattern02.mediator.e22;

public interface IMediator {
    public void childChanged(Object child);
}
